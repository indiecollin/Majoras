import React from 'react';
import styled from 'styled-components';
import Ocarina from '../public/Items/ocarina-of-time.png';
import Bow from '../public/Items/heros-bow.png';
import FireArrow from '../public/Items/fire-arrow.png';
import IceArrow from '../public/Items/ice-arrow.png';
import LightArrow from '../public/Items/light-arrow.png';
import Bomb from '../public/Items/bomb.png';
import Bombchu from '../public/Items/bombchu.png';
import DekuStick from '../public/Items/deku-stick.png';
import DekuNut from '../public/Items/deku-nut.png';
import MagicBeans from '../public/Items/magic-beans.png';
import PowderKeg from '../public/Items/powder-keg.png';
import Pictograph from '../public/Items/pictograph-box.png';
import LensOfTruth from '../public/Items/lens-of-truth.png';
import Hookshot from '../public/Items/hookshot.png';
import FairySword from '../public/Items/great-fairys-sword.png';
import BottleMilk from '../public/Items/bottle1.png';
import BottleMagic  from '../public/Items/bottle2.png';
import BottleFairy from '../public/Items/bottle3.png';
import BottleFish from '../public/Items/bottle4.png';
import BottleGold from '../public/Items/bottle5.png';
import Bottle from '../public/Items/bottle6.png';

const ItemsContainer = styled.div`
    background-color: wheat;
    display: flex;
    flex-direction: column;    
    h1{
        margin: 0 auto;
        text-transform: uppercase;
        padding: 16px 20px;
        font-size: 50px;
    }
    &>div{        
        padding: 0 120px 60px;

        &>div{
            background-color: #0B0B0F;
            display: flex;
            flex-direction: column;
            position: relative;
        }
    }    
`;

const ItemRow = styled.div`
    display: flex;
    justify-content: space-between;              
      padding: 8px;
    img{
        width: 148px;
        z-index: 200;
    }
`;

const ArrowBar = styled.div`
    position: absolute;
    background-color: darkgoldenrod;
    width: 100px;
    height: 32px;
    top: 32px;
    left: 380px;
    z-index: 100;
    span{
        
    }
`;
const BottleBar = styled.span`
    position: absolute;
`;
const QuestBar = styled.span`
    position: absolute;
`;

const Items = () => {
    return <ItemsContainer>
        <h1>select item</h1>
        <div>
            <div>
                <ItemRow>
                    <img src={Ocarina}/>
                    <img src={Bow}/>
                    <img src={FireArrow}/>
                    <img src={IceArrow}/>
                    <img src={LightArrow}/>
                    <img src = ''/>
                </ItemRow>
                <ItemRow>
                    <img src={Bomb}/>
                    <img src={Bombchu}/>
                    <img src={DekuStick}/>
                    <img src={DekuNut}/>
                    <img src={MagicBeans}/>
                    <img src = ''/>
                </ItemRow>
                <ItemRow>
                    <img src={PowderKeg}/>
                    <img src={Pictograph}/>
                    <img src={LensOfTruth}/>
                    <img src={Hookshot}/>
                    <img src={FairySword}/>
                    <img src = ''/>
                </ItemRow>
                <ItemRow>
                    <img src={BottleMilk}/>
                    <img src={BottleMagic}/>
                    <img src={BottleFairy}/>
                    <img src={BottleFish}/>
                    <img src={BottleGold}/>
                    <img src={Bottle}/>
                </ItemRow>
                <ArrowBar/>
                <BottleBar/>
                <QuestBar/>
            </div>            
        </div>
    </ItemsContainer>
}


export default Items;